1. ضع التوكن في bot.js
2. ثبت Node.js
3. اكتب:
npm install
4. شغل:
node bot.js