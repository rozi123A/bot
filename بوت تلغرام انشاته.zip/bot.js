const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs-extra');

const token = "6337104307:AAGswhTagb7VYS1P88izvNTNNoHwNWOcQ08";
const bot = new TelegramBot(token, { polling: true });

const DB_FILE = "database.json";

// تحميل البيانات
let db = fs.existsSync(DB_FILE) ? fs.readJsonSync(DB_FILE) : { users: {} };

// حفظ البيانات
function saveDB() {
  fs.writeJsonSync(DB_FILE, db, { spaces: 2 });
}

// إنشاء مستخدم
function getUser(id) {
  if (!db.users[id]) {
    db.users[id] = {
      balance: 0,
      lastSpin: 0,
      referrals: 0
    };
  }
  return db.users[id];
}

// قائمة الأزرار
function mainMenu() {
  return {
    reply_markup: {
      keyboard: [
        ["🎮 لعب", "💰 رصيدي"],
        ["📢 إعلان", "👥 دعوة"],
        ["🏧 سحب"]
      ],
      resize_keyboard: true
    }
  };
}

// بدء
bot.onText(/\/start(.*)/, (msg, match) => {
  let id = msg.chat.id;
  let user = getUser(id);

  // نظام الإحالة
  let ref = match[1];
  if (ref && db.users[ref] && ref != id) {
    db.users[ref].balance += 0.01;
    db.users[ref].referrals += 1;
  }

  saveDB();

  bot.sendMessage(id, "👋 مرحباً بك في بوت الربح!", mainMenu());
});

// التعامل مع الأزرار
bot.on("message", (msg) => {
  let id = msg.chat.id;
  let text = msg.text;
  let user = getUser(id);

  // 🎮 لعب
  if (text === "🎮 لعب") {
    let now = Date.now();

    if (now - user.lastSpin < 60000) {
      return bot.sendMessage(id, "⏳ انتظر دقيقة");
    }

    user.lastSpin = now;

    let rewards = [0.001, 0.002, 0.005, 0.01];
    let win = rewards[Math.floor(Math.random() * rewards.length)];

    user.balance += win;

    saveDB();

    bot.sendMessage(id, `🎯 ربحت ${win} USDC\n💰 رصيدك: ${user.balance}`);
  }

  // 💰 رصيدي
  if (text === "💰 رصيدي") {
    bot.sendMessage(id, `💰 رصيدك: ${user.balance}`);
  }

  // 📢 إعلان
  if (text === "📢 إعلان") {
    bot.sendMessage(id, "📢 شاهد الإعلان:\nhttps://your-ad-link.com");
  }

  // 👥 دعوة
  if (text === "👥 دعوة") {
    bot.sendMessage(id,
      `🔗 رابطك:\nhttps://t.me/YOUR_BOT_USERNAME?start=${id}`
    );
  }

  // 🏧 سحب
  if (text === "🏧 سحب") {
    if (user.balance >= 1) {
      bot.sendMessage(id, "✅ تم إرسال طلب السحب");
    } else {
      bot.sendMessage(id, "❌ الحد الأدنى 1 USDC");
    }
  }
});